package beka.com.bk.dushanbeonline;

public interface OpenCloseListener {

    void onClose();

    void onOpen();

}
