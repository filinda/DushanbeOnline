package beka.com.bk.dushanbeonline;

import java.util.Date;

public class TaskData {
    public double lat = 0, lon = 0;
    public String adress = "unknown";
    public Date dateStart;
    public int price = 0;
    public boolean buget = true;
    public boolean paymentType = true;
    public String name = "unknown", desc = "unknown", addDesc = "unknown";
}
