package beka.com.bk.dushanbeonline.custom_views;

public interface changeListener {

    void onChange(boolean isOn);
    void onChange(int lang);

}