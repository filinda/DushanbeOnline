package beka.com.bk.dushanbeonline;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;

import beka.com.bk.dushanbeonline.custom_views.CustomPublishBtn;
import beka.com.bk.dushanbeonline.custom_views.MuliLayerList;
import beka.com.bk.dushanbeonline.custom_views.TopLabel;

public class AddRemoveCategories extends Activity {

    FrameLayout layout, sclLayout;
    ScrollView scrollView;
    TopLabel label;
    float scale=1;
    String[][] strings;
    int lang = 1;
    DisplayMetrics dm;
    TextView underlabel;
    CustomPublishBtn saveBtn;
    MuliLayerList k;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        layout = new FrameLayout(this);
        setContentView(layout);

        lang = getIntent().getIntExtra("lang", 1);

        dm = getResources().getDisplayMetrics();
        scale = dm.widthPixels/1080f;

        strings = new String[2][3];
        strings[0][0] = "Choose categories";
        strings[1][0] = "Выберите категории";
        strings[0][1] = "List of categories";
        strings[1][1] = "Список категорий";
        strings[0][2] = "Add";
        strings[1][2] = "Добавить";

        label = new TopLabel(this,strings[lang][0],scale);
        label.setBackOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onBackPressed();
            }
        });
        layout.addView(label);

        saveBtn = new CustomPublishBtn(this,ResourseColors.colorGreen,strings[lang][2]);
        saveBtn.setLayoutParams(new FrameLayout.LayoutParams((int) (1080 * scale), (int) (141 * scale)));
        saveBtn.setY(dm.heightPixels-141*scale);
        layout.addView(saveBtn);
        saveBtn.invalidate();

        scrollView = new ScrollView(this);
        scrollView.setX(0);
        scrollView.setY(122*scale+168*scale);
        scrollView.setLayoutParams(new FrameLayout.LayoutParams((int)(1080*scale),(int)(dm.heightPixels-168*scale-122*scale-141*scale)));

        sclLayout = new FrameLayout(this);

        System.out.println("abab create");
        k = new MuliLayerList(this,(int)(1080*scale),getResources().getDisplayMetrics().heightPixels,lang);
        k.setY(0*scale);
        sclLayout.addView(k);
        k.all.baseLayout=sclLayout;
        k.all.postBaseLayout=k;

        underlabel = new TextView(this);
        underlabel.setTypeface(Typeface.createFromAsset(getAssets(),"font.ttf"));
        underlabel.setGravity(Gravity.CENTER_HORIZONTAL);
        underlabel.setTextColor(ResourseColors.colorLightGray);
        underlabel.setTextSize(TypedValue.COMPLEX_UNIT_PX,40*scale);
        underlabel.setY((168+50)*scale);
        underlabel.setText(strings[lang][1]);
        layout.addView(underlabel);

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int checkedViews = 0;
                ArrayList<String> categories = new ArrayList<>();
                for(int i = 0;i<k.all.childs.size();i++){
                    if(k.all.childs.get(i).isChecked) {
                        checkedViews++;
                        categories.add(i+"-*-*");
                    }
                    for(int j = 0;j<k.all.childs.get(i).childs.size();j++){
                        if(k.all.childs.get(i).childs.get(j).isChecked) {
                            checkedViews++;
                            categories.add(i+"-"+j+"-*");
                        }
                        for(int p = 0;p<k.all.childs.get(i).childs.get(j).childs.size();p++){
                            if(k.all.childs.get(i).childs.get(j).childs.get(p).isChecked) {
                                checkedViews++;
                                categories.add(i+"-"+j+"-"+p);
                            }
                        }
                    }
                }

                DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("usersInfo").child(FirebaseAuth.getInstance().getCurrentUser().getUid()).child("profiInfo").child("categories");
                for(int i =0;i<categories.size();i++){
                    reference.child(""+i).setValue(categories.get(i));
                }
            }
        });

        layout.addView(scrollView);
        scrollView.addView(sclLayout);
    }
}

