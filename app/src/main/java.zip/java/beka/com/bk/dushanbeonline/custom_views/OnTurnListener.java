package beka.com.bk.dushanbeonline.custom_views;

public class OnTurnListener {
    public void onTurn(boolean state){}
}
